package com.example.autofish

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.Display
import android.accessibilityservice.GestureDescription
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class FishAccessibilityService : AccessibilityService() {
    private val handler=Handler(Looper.getMainLooper())
    private val busy=AtomicBoolean(false)
    private var lastPrompt=false
    private var lastCast=0L
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { handler.removeCallbacks(loop) }
    override fun onServiceConnected() { handler.post(loop) }
    override fun onDestroy() { handler.removeCallbacks(loop); super.onDestroy() }

    private val loop=object:Runnable {
        override fun run() {
            val prefs=getSharedPreferences("fish", MODE_PRIVATE)
            if (android.os.Build.VERSION.SDK_INT >= 30 && busy.compareAndSet(false,true)) {
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object:TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        val buffer=result.hardwareBuffer
                        val bitmap=Bitmap.wrapHardwareBuffer(buffer,result.colorSpace)
                        buffer.close()
                        if (bitmap==null) { busy.set(false); return }
                        val copy=bitmap.copy(Bitmap.Config.ARGB_8888,false)
                        bitmap.recycle()
                        recognizer.process(InputImage.fromBitmap(copy,0))
                            .addOnSuccessListener { text ->
                                val cue=prefs.getString("prompt","Нажимайте быстро!") ?: "Нажимайте быстро!"
                                val found=text.text.contains(cue,ignoreCase=true)
                                if (found) {
                                    lastPrompt=true
                                    tap(prefs.getInt("tapX",50),prefs.getInt("tapY",80))
                                } else if (lastPrompt) {
                                    lastPrompt=false
                                    lastCast=System.currentTimeMillis()
                                } else if (System.currentTimeMillis()-lastCast>2500) {
                                    // Avoid repeated blind casting: cast only once after prompt has disappeared.
                                    tap(prefs.getInt("castX",50),prefs.getInt("castY",85))
                                    lastCast=System.currentTimeMillis()
                                }
                            }
                            .addOnCompleteListener { copy.recycle(); busy.set(false) }
                    }
                    override fun onFailure(errorCode: Int) { busy.set(false) }
                })
            }
            handler.postDelayed(this,prefs.getInt("interval",800).coerceAtLeast(500).toLong())
        }
    }

    private fun tap(px:Int,py:Int) {
        val dm=resources.displayMetrics
        val x=dm.widthPixels*px.coerceIn(0,100)/100f
        val y=dm.heightPixels*py.coerceIn(0,100)/100f
        val path=Path().apply { moveTo(x,y) }
        val gesture=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,70)).build()
        dispatchGesture(gesture,null,null)
    }
}
