package com.example.autofish

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("fish", MODE_PRIVATE)
        val prompt = EditText(this).apply { hint = "Текст поклёвки"; setText(prefs.getString("prompt", "Нажимайте быстро!")) }
        val tapX = EditText(this).apply { hint = "X нажатия (0–100% ширины)"; inputType=2; setText(prefs.getInt("tapX",50).toString()) }
        val tapY = EditText(this).apply { hint = "Y нажатия (0–100% высоты)"; inputType=2; setText(prefs.getInt("tapY",80).toString()) }
        val castX = EditText(this).apply { hint = "X заброса (0–100%)"; inputType=2; setText(prefs.getInt("castX",50).toString()) }
        val castY = EditText(this).apply { hint = "Y заброса (0–100%)"; inputType=2; setText(prefs.getInt("castY",85).toString()) }
        val interval = EditText(this).apply { hint = "Интервал проверки, мс (не менее 500)"; inputType=2; setText(prefs.getInt("interval",800).toString()) }
        val status = TextView(this).apply { text = "1) Сохрани координаты. 2) Включи службу доступности. 3) Открой Roblox и запусти Auto Fish."; textSize=16 }
        val save = Button(this).apply { text="Сохранить настройки"; setOnClickListener {
            fun num(e: EditText, d:Int)=e.text.toString().toIntOrNull()?.coerceIn(0,100) ?: d
            prefs.edit().putString("prompt",prompt.text.toString())
                .putInt("tapX",num(tapX,50)).putInt("tapY",num(tapY,80))
                .putInt("castX",num(castX,50)).putInt("castY",num(castY,85))
                .putInt("interval",(interval.text.toString().toIntOrNull() ?: 800).coerceAtLeast(500)).apply()
            status.text="Настройки сохранены. Для запуска открой Roblox и используй кнопку службы Auto Fish."
        } }
        val access = Button(this).apply { text="Открыть настройки специальных возможностей"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_HORIZONTAL; setPadding(28,24,28,24) }
        layout.addView(TextView(this).apply { text="Auto Fish"; textSize=26 })
        listOf(prompt,tapX,tapY,castX,castY,interval,save,access,status).forEach { layout.addView(it) }
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
